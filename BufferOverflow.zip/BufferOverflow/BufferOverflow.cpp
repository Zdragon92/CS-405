// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // Place holder for user input
  std::string user_temp;
  const std::string account_number = "CharlieBrown42";
  char user_input[20];
 
  std::cout << "Enter a value: "; 
  std::cin >> user_temp;

  // If check input is too large  
  if (size(user_temp) > sizeof(user_input)) {
	  // Change input to notify user of issue
	  // And to prevent buffer overflow.
	  user_temp = "Input Too Large.";
  }
  // copy the string to character array
  strcpy_s(user_input, user_temp.c_str());

  std::cout << "You entered: " << user_input << std::endl;
  
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
